var showNav = function(){
$("header").show();
document.getElementById("tree").style.width="15em";
document.getElementById("tree").style.marginLeft="12em";
};


var hideNav = function(){
$("header").hide();
document.getElementById("tree").style.width="27em";
document.getElementById("tree").style.marginLeft="0em";
};
